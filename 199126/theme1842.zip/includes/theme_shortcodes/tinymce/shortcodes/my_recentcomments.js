frameworkShortcodeAtts={
	attributes:[
			{
				label:"How many comments to show?",
				id:"num",
				help:"This is how many recent comments will be displayed."
			}
	],
	defaultContent:"",
	shortcode:"recent_comments",
	shortcodeType: "text-replace"
};