frameworkShortcodeAtts={
	attributes:[
			{
				label:"File",
				id:"file",
				help:"Enter the full url to the audio file like this:<br/>http://demolink.org/uploads/file.mp3"
			},
			{
				label:"Description",
				id:"desc",
				help:"Description for your file."
			}
			
	],
	defaultContent:"",
	shortcode:"audio"
};
