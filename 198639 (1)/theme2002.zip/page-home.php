<?php
/**
 * Template Name: Home Page
 */

get_header(); ?>

<div class="delimiter">
<div class="container_12">
<div class="grid_12">
  	<?php if ( ! dynamic_sidebar( 'Content Area2' ) ) : ?>
      <!--Widgetized 'Content Area2' for the home page-->
    <?php endif ?>
</div>
</div>
</div>
<div class="delimiter1">
<div class="container_12">
  	<?php if ( ! dynamic_sidebar( 'After Content Area' ) ) : ?>
      <!--Widgetized 'After Content Area' for the home page-->
    <?php endif ?>
</div>
</div>
<?php get_footer(); ?>