    <?php $post_meta = of_get_option('post_meta'); ?>
		<?php if ($post_meta=='true' || $post_meta=='') { ?>
			<div class="post-meta">
				<div class="fleft"><time datetime="<?php 

the_time('Y-m-d\TH:i'); ?>"><?php the_time('m. d. Y'); ?></time><span class="delim">|</span><?php _e('posted by:', 'theme2002'); ?> <?php the_author_posts_link() ?><span class="delim">|</span><?php comments_popup_link('no comments', 'comment: 1', 'comments: %', 'comments-link', 'comments are closed'); ?></div>
			</div><!--.post-meta-->
		<?php } ?>		
