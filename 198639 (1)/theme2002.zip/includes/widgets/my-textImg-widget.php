<?php
// =============================== My Text Image Widget ======================================
class MY_TextImageWidget extends WP_Widget {
    /** constructor */
    function MY_TextImageWidget() {
        parent::WP_Widget(false, $name = 'My - Text & Image');	
    }

    /** @see WP_Widget::widget */
    function widget($args, $instance) {		
        extract( $args );
        $title = apply_filters('widget_title', $instance['title']);
				$txt1 = apply_filters('widget_txt1', $instance['txt1']);
				$img1 = apply_filters('widget_img1', $instance['img1']);
				$url1 = apply_filters('widget_url1', $instance['url1']);
				$color1 = apply_filters('widget_color1', $instance['color1']);
				$textcolor = apply_filters('textcolor', $instance['textcolor']);				
	
        ?>
              
		
              <?php echo $before_widget; ?>			  			
					<div class="img-box">
						<a href="<?php echo $url1; ?>" class="banner">
							<?php if($img1!="") { ?><img src="<?php echo $img1; ?>" alt=""/><span class="over-shad"></span><?php } ?>
								<div class="bg-boxImg">
									<?php if($title!=""){ ?>
										<div class="box-text <?php echo $class; ?>">
											<h3><?php echo $title; ?></h3>
											<?php echo $txt1; ?>
										</div><!-- end 'with title' -->
										<?php } else { ?>
										<div class="box-text <?php echo $class; ?>">
											<?php echo $txt1; ?>
										</div><!-- end 'without title' -->
									<?php } ?>
								</div>
							</a>
						</div>
              <?php echo $after_widget; ?>
        <?php
    }

    /** @see WP_Widget::update */
    function update($new_instance, $old_instance) {				
        return $new_instance;
    }

    /** @see WP_Widget::form */
    function form($instance) {				
        $title = esc_attr($instance['title']);
				$txt1 = esc_attr($instance['txt1']);
				$img1 = esc_attr($instance['img1']);
				$url1 = esc_attr($instance['url1']);
        ?>
       <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'theme2002'); ?> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
			 <p><label for="<?php echo $this->get_field_id('txt1'); ?>"><?php _e('Text:', 'theme2002'); ?><textarea rows="5"  class="widefat" id="<?php echo $this->get_field_id('txt1'); ?>" name="<?php echo $this->get_field_name('txt1'); ?>"><?php echo $txt1; ?></textarea></label></p>
			<p><label for="<?php echo $this->get_field_id('img1'); ?>"><?php _e('Image:', 'theme2002'); ?> <input class="widefat" id="<?php echo $this->get_field_id('img1'); ?>" name="<?php echo $this->get_field_name('img1'); ?>" type="text" value="<?php echo $img1; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id('url1'); ?>"><?php _e('Url:', 'theme2002'); ?> <input class="widefat" id="<?php echo $this->get_field_id('url1'); ?>" name="<?php echo $this->get_field_name('url1'); ?>" type="text" value="<?php echo $url1; ?>" /></label></p>
			

<?php } } // class Request Quote Widget

?>