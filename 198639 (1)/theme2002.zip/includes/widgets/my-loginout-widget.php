<?php

function register( $before = '', $after = '', $echo = true ) {
	if ( ! is_user_logged_in() ) { 
		if ( get_option('users_can_register') )
			$link = $before . '<a href="' . site_url('wp-login.php?action=register', 'login') . '">' . __('Sign up') . '</a>' . $after;
		else
			$link = '';
	} else {
		$link = $before . '<a href="' . admin_url() . '">' . __('Site Admin') . '</a>' . $after;
	}

	if ( $echo )
		echo apply_filters('register', $link);
	else
		return apply_filters('register', $link);
}

function loginout($redirect = '', $echo = true) {
	if ( ! is_user_logged_in() )
		$link = '<a href="' . esc_url( wp_login_url($redirect) ) . '">' . __('Sign in') . '</a>';
	else
		$link = '<a href="' . esc_url( wp_logout_url($redirect) ) . '">' . __('Sign out') . '</a>';

	if ( $echo )
		echo apply_filters('loginout', $link);
	else
		return apply_filters('loginout', $link);
}

// =============================== My Request Quote Widget ======================================
class MY_LoginoutWidget extends WP_Widget {
	/** constructor */
	function MY_LoginoutWidget() {
		parent::WP_Widget(false, $name = 'My - Login/Logout');
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance) {
		extract( $args );
		$txt = apply_filters('widget_txt', $instance['txt']);
		$class = apply_filters('widget_class', $instance['class']);

		echo $before_widget; ?>

		<div id="loginout" class="loginout-widget <?php if($class!="") echo ' ' . $class; ?>">
			<span class="txt"><?php if (!is_user_logged_in()) {
				if($txt!="") echo $txt . ' ';
				else _e('Have an account? ', 'theme2002');
			}?></span>
			<?php loginout(); 
			if ( get_option('users_can_register') ) { register(_e(' or ', 'theme2002'), ''); } ?>
		</div>

		<?php echo $after_widget;
	}

	/** @see WP_Widget::update */
	function update($new_instance, $old_instance) {
		return $new_instance;
	}

	/** @see WP_Widget::form */
	function form($instance) {
		$txt = esc_attr($instance['txt']);
		$class = esc_attr($instance['class']);?>

		<p>
			<label><?php _e('Before links text:', 'theme2002'); ?>
				<input class="widefat" id="<?php echo $this->get_field_id('txt'); ?>" name="<?php echo $this->get_field_name('txt'); ?>" type="text" value="<?php echo $txt; ?>">
			</label>
		</p>
		<p>
			<label><?php _e('Custom class:', 'theme2002'); ?>
				<input class="widefat" id="<?php echo $this->get_field_id('class'); ?>" name="<?php echo $this->get_field_name('class'); ?>" type="text" value="<?php echo $class; ?>">
			</label>
		</p>
	<?php }
} // class Request Quote Widget ?>