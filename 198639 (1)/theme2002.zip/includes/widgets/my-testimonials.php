<?php
/*
// =============================== My testimonials ======================================*/
class MY_PostsTestimonials extends WP_Widget {

function MY_PostsTestimonials() {
		$widget_ops = array('classname' => 'my_testimonials', 'description' => __('Show custom posts'));
		$control_ops = array('width' => 250, 'height' => 350);
	    parent::WP_Widget(false, __('My - Posts Testimonials'), $widget_ops, $control_ops);
}

/**
 * Displays custom posts widget on blog.
 */
function widget($args, $instance) {
	global $post;
	$post_old = $post; // Save the post object.
	
	extract( $args );
	$limit = apply_filters('widget_limit', $instance['limit']);
  $valid_sort_orders = array('date', 'title', 'comment_count', 'rand');
 
    // by default, display latest first
    $sort_by = 'date';
    $sort_order = 'DESC';
  
	
	// Get array of post info.
	$args = array(
		'showposts' => $instance["num"],
		'post_type' => 'testi',
		'orderby' => 'date',
		'order' => 'DESC',
		'category_name' => $category,
		'tax_query' => array(
		 'relation' => 'AND',
			array(
				'taxonomy' => 'post_format',
				'field' => 'slug',
				'terms' => array('post-format-aside', 'post-format-gallery', 'post-format-link', 'post-format-image', 'post-format-quote', 'post-format-audio', 'post-format-video'),
				'operator' => 'NOT IN'
			)
		)
	);
	
	
  $cat_posts = new WP_Query($args);
  
	
	echo $before_widget;
	
	// Widget title
	// If title exist.
	if( $instance["title"] ) {
	echo $before_title;
		echo $instance["title"];
	echo $after_title;
    }

	// Posts list
    if($instance['container_class']==""){
	echo "<ul class='post_list'>\n";
	}else{
    echo "<ul class='post_list " .$instance['container_class'] ."'>\n";
    }
	
	$limittext = $limit;
	$posts_counter = 0;
	while ( $cat_posts->have_posts() )
	{
		$cat_posts->the_post(); $posts_counter++;
	?>
    <?php if ($instance['posttype'] == "testi") {
      $custom = get_post_custom($post->ID);
      $testiname = $custom["my_testi_caption"][0];
			$testiurl = $custom["my_testi_url"][0];
			$testiinfo = $custom["my_testi_info"][0];
			$limit = esc_attr($instance['limit']);
    }
    $thumb = get_post_thumbnail_id();
      $img_url = wp_get_attachment_url( $thumb,'full'); //get img URL	
      $image = aq_resize( $img_url, $instance['thumb_w'], $instance['thumb_h'], true ); //resize & crop img
    ?>
		<li class="testi-class cat_post_item-<?php echo $posts_counter; ?> clearfix">
		<img src="<?php bloginfo('stylesheet_directory'); ?>/images/testi_icon.png" alt="">
			<?php if ($instance["thumb"]) : ?>
			  <?php if (has_post_thumbnail($post->ID)) : ?>
				<figure class="featured-thumbnail">
			  <?php if ( $instance['thumb_as_link'] ) : ?>
						<a href="<?php the_permalink() ?>">
					<?php endif; ?>
					<?php if($instance['thumb_w']!=="" || $instance['thumb_h']!==""){ ?>
						<img src="<?php echo $image; ?>" alt="<?php the_title(); ?>" />
					<?php }else{?>
						<?php the_post_thumbnail(); ?>
					<?php }?>
					<?php if ( $instance['thumb_as_link'] ) : ?>
						</a>
					<?php endif; ?>
				</figure>
			  <?php endif; ?>	
			<?php endif; ?>	
            <?php if ( $instance['show_title'] ) : ?>
			  <?php echo $instance["before_post_title"]; ?><a class="post-title" href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php if ( $instance['show_title_date'] ) {?>[<?php the_time('m-d-Y'); ?>]<?php }else{?><?php the_title(); ?><?php }?></a><?php echo $instance["after_post_title"]; ?>
			<?php endif; ?>
			
			  <div class="post-meta-wrapper">
					
					<?php if ( $instance['date'] ) : ?>
						<span class="post_meta">Written by <?php the_author_posts_link() ?> <time datetime="<?php the_time('Y-m-d\TH:i'); ?>"><?php the_time('l, j F Y'); ?> <?php the_time() ?></time></span>
					<?php endif; ?>
					
					<?php if ( $instance['comment_num'] ) : ?>
						<span class="post_comment">(<?php comments_number(); ?>)</span>
					<?php endif; ?>
				
				</div>
				
				
			<div class="post_content">
			
			<?php if ($instance['posttype'] == "testi") { ?>
						 <div class="name-testi">
							 <span class="user"><?php echo $testiname; ?></span>,
							 <a href="<?php echo $testiurl; ?>"><?php echo $testiurl; ?></a><br/>
							 <span class="info"><?php echo $testiinfo; ?></span>
						 </div>
            <?php }?>
			
            <?php if ( $instance['excerpt'] ) : ?>
			<?php if($limit!="" || $limit!=0) : ?>
			<?php $content = get_the_content(); echo my_string_limit_words($content,$limit);?>			  <?php endif; ?>
            <?php endif; ?>
			<div class="clear"></div>
			<?php if ( $instance['more_link'] ) : ?>
              <a href="<?php the_permalink() ?>" class="<?php if($instance['more_link_class']!="") {echo $instance['more_link_class'];}else{ ?>button<?php } ?>"><?php if($instance['more_link_text']==""){ ?>More<?php }else{ ?><?php echo $instance['more_link_text']; ?><?php } ?></a>
            <?php endif; ?>
			
            </div>
			
            
		</li>
	<?php } ?>
	<?php echo "</ul>\n"; ?>
	<?php if ( $instance['global_link'] ) : ?>
	  <a href="<?php echo $instance['global_link_href']; ?>" class="link_show_all"><?php if($instance['global_link_text']==""){ ?>View all<?php }else{ ?><?php echo $instance['global_link_text']; ?><?php } ?></a>
	<?php endif; ?>
	
<?php 	
	echo $after_widget;
	
	$post = $post_old; // Restore the post object.
}

/**
 * Form processing.
 */
function update($new_instance, $old_instance) {
	return $new_instance;
}

/**
 * The configuration form.
 */
function form($instance) {
$limit = esc_attr($instance['limit']);
?>
<p>
    <label for="<?php echo $this->get_field_id("title"); ?>">
        <?php _e( 'Title' ); ?>:
        <input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
    </label>
</p>
 
<p>
      <label for="<?php echo $this->get_field_id("num"); ?>">
          <?php _e('Number of posts to show'); ?>:
          <input style="text-align: center;" id="<?php echo $this->get_field_id("num"); ?>" name="<?php echo $this->get_field_name("num"); ?>" type="text" value="<?php echo absint($instance["num"]); ?>" size='4' />
      </label>
</p>



<p>
  <label for="<?php echo $this->get_field_id("container_class"); ?>">
    <?php _e( 'Container class' ); ?>:
    <input class="widefat" id="<?php echo $this->get_field_id("container_class"); ?>" name="<?php echo $this->get_field_name("container_class"); ?>" type="text" value="<?php echo esc_attr($instance["container_class"]); ?>" /> <span style="font-size:11px; color:#999;"><?php _e( '(default: "featured_custom_posts")' ); ?></span>
  </label>
</p>


  
  <legend style="padding:0 0 10px;"><?php _e('Excerpt'); ?>:</legend>
  <p>
      <label for="<?php echo $this->get_field_id("excerpt"); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("excerpt"); ?>" name="<?php echo $this->get_field_name("excerpt"); ?>"<?php checked( (bool) $instance["excerpt"], true ); ?> />
          <?php _e( 'Show post excerpt' ); ?>
      </label></p>
	  
	  <p><label for="<?php echo $this->get_field_id('limit'); ?>"><?php _e('Limit Text:', 'theme2002'); ?> <input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label></p>  
 
  <p>
      <label for="<?php echo $this->get_field_id("more_link"); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("more_link"); ?>" name="<?php echo $this->get_field_name("more_link"); ?>"<?php checked( (bool) $instance["more_link"], true ); ?> />
          <?php _e( 'Show "More link"' ); ?>
      </label>
  </p>


<?php

}
}
?>